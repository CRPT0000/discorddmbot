# MassDM
***Use this tool at your own risk!***

You will need one thing installed to make this bot work. Simply open up a terminal in the bot folder and type `npm install -d`. It can get the prerequisite program for you, and get the libraries needed for this bot to run! 

+ Node.js(LTS version). [https://nodejs.org/en/](https://nodejs.org/en/)
+ Discord.js(LTS version). [https://www.npmjs.com/package/discord.js](https://www.npmjs.com/package/discord.js)

*Open `index.js` in your code editor and edit the token with your bot token.*

+ Additionally, you can change the prefix in `config.json`, modify the ID of the user in `whitelist.json` who will control the bot.

Once you have completed all of the above, you may run `node index.js` or create a bat file with `node index.js`

> Created by swirls#0001
